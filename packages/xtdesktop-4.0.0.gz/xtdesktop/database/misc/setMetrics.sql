select setMetric('desktop/welcome',
                 'http://welcome.xtuple.org/index.html');
select setMetric('desktop/timer','900000');
