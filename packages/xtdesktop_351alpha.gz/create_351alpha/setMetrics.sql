select setMetric('desktop/welcome','http://www.xtuple.org/client/welcome');
select setMetric('desktop/timer','900000');